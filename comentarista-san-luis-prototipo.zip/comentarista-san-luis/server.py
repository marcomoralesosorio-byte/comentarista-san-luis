"""Backend for a single-user prototype. Deploy behind HTTPS with authentication."""
import os, tempfile
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from openai import AsyncOpenAI

app = FastAPI(title='Comentarista Deportivo IA - San Luis')
client = AsyncOpenAI(api_key=os.getenv('OPENAI_API_KEY', ''))
BASE = Path(__file__).parent / 'static'
MAX_BYTES = 8 * 1024 * 1024

@app.get('/')
async def home():
    return FileResponse(BASE / 'index.html')

@app.get('/manifest.webmanifest')
async def manifest():
    return FileResponse(BASE / 'manifest.webmanifest', media_type='application/manifest+json')

@app.get('/sw.js')
async def sw():
    return FileResponse(BASE / 'sw.js', media_type='application/javascript')

@app.get('/icon.svg')
async def icon():
    return FileResponse(BASE / 'icon.svg', media_type='image/svg+xml')

@app.post('/api/transcribe')
async def transcribe(audio: UploadFile = File(...)):
    if not os.getenv('OPENAI_API_KEY'):
        raise HTTPException(503, 'Falta configurar OPENAI_API_KEY en el servidor')
    data = await audio.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise HTTPException(413, 'Fragmento demasiado grande')
    suffix = '.webm' if 'webm' in (audio.content_type or '') else '.mp4'
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
        f.write(data)
        path = f.name
    try:
        with open(path, 'rb') as f:
            result = await client.audio.transcriptions.create(model='gpt-4o-mini-transcribe', file=f, language='es')
        return {'text': result.text}
    finally:
        os.unlink(path)

class AnalysisRequest(BaseModel):
    recent: str
    context: str = ''
    previous: str = ''
    team: str = 'San Luis de Quillota'

@app.post('/api/analyze')
async def analyze(req: AnalysisRequest):
    if not os.getenv('OPENAI_API_KEY'):
        raise HTTPException(503, 'Falta configurar OPENAI_API_KEY en el servidor')
    if len(req.recent.strip()) < 60:
        return {'comment': 'Audio insuficiente para un análisis fundamentado. Se mantiene la escucha.', 'insufficient': True}
    result = await client.chat.completions.create(
        model=os.getenv('ANALYSIS_MODEL', 'gpt-4.1-mini'),
        temperature=0.3,
        messages=[
            {'role':'system','content':f'''Eres analista radial de fútbol desde la perspectiva de {req.team}. Escribe en español chileno profesional un comentario de aproximadamente 60 palabras. Solo afirma hechos explícitamente presentes en la transcripción; no inventes goles, minutos, jugadores, tácticas observadas ni marcador. Distingue interpretación de hecho. No repitas el comentario anterior. Si el relato no aporta suficiente información, indica de manera breve que no hay evidencia suficiente para un análisis nuevo. Devuelve solo el comentario.''' },
            {'role':'user','content':f'Contexto previo:\n{req.context[-6500:]}\n\nÚltimos minutos:\n{req.recent[-10000:]}\n\nComentario anterior:\n{req.previous[-1000:]}'}
        ], max_tokens=180
    )
    return {'comment': result.choices[0].message.content or '', 'insufficient': False}
