# Comentarista Deportivo IA – San Luis

Prototipo experimental para Chrome Android (PWA) con backend Python. Captura el micrófono, envía fragmentos de 20 segundos para transcripción y solicita un análisis cada 5 minutos o al pulsar «Analizar ahora». No es una APK y no está desplegado.

## Requisitos
- Hosting HTTPS capaz de ejecutar Python/FastAPI (no basta hosting estático).
- Cuenta de API OpenAI y `OPENAI_API_KEY` configurada como variable de entorno del servidor.
- Chrome Android, permiso de micrófono, pantalla encendida y conexión estable.
- Para uso público, agregar autenticación, límites de consumo y protección de datos antes de desplegar.

## Ejecución
```bash
pip install -r requirements.txt
export OPENAI_API_KEY='TU_CLAVE_EN_EL_SERVIDOR'
uvicorn server:app --host 0.0.0.0 --port 8000
```
Publicar detrás de HTTPS; desde Chrome abrir la URL y seleccionar «Agregar a pantalla de inicio» o «Instalar aplicación».

## Limitaciones
- Los fragmentos se procesan al finalizar cada bloque de 20 segundos; no es transcripción palabra por palabra en vivo.
- La API de transcripción cobra por uso y puede requerir ajustes según formatos y tarifas vigentes.
- Si se detiene o bloquea la página, la captura puede interrumpirse.
- No hay identificación confiable de jugadores ni comprobación externa del marcador.
- No hay pruebas de extremo a extremo ni despliegue; se necesita verificar el proyecto en un Android real.
- La primera versión usa memoria solo durante la sesión y no almacena audio en el servidor de forma permanente.
